// Variables here




function setup() {
  createCanvas(400, 400);

}

function draw() {
  background(220);
  
  
  

  // helper code, feel free to comment out
	textSize(15);
	fill(255);
	stroke(0);
	strokeWeight(2);
	text("x: " + int(mouseX) + " y: " + int(mouseY), 30, 30);
  
}